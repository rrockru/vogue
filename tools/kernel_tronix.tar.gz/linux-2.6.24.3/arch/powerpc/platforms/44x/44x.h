#ifndef __POWERPC_PLATFORMS_44X_44X_H
#define __POWERPC_PLATFORMS_44X_44X_H

extern u8 as1_readb(volatile u8 __iomem  *addr);
extern void as1_writeb(u8 data, volatile u8 __iomem *addr);
extern void ppc44x_reset_system(char *cmd);

#endif /* __POWERPC_PLATFORMS_44X_44X_H */
