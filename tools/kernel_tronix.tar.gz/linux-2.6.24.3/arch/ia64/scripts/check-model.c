int __attribute__ ((__model__ (__small__))) x;
